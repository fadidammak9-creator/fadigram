// Basic sidebar button interactions and toggle behavior
const buttons = document.querySelectorAll('.nav-btn');
const panels = document.querySelectorAll('.panel');
const pageTitle = document.getElementById('pageTitle');
const sidebar = document.getElementById('sidebar');
const toggleBtn = document.getElementById('toggleBtn');
const mobileMenuBtn = document.getElementById('mobileMenuBtn');
const languageSelect = document.getElementById('languageSelect');

// Simple translations
const translations = {
  en: {
    home: 'Home',
    about: 'About',
    settings: 'Settings',
    help: 'Help',
    settings_title: 'Settings',
    language_label: 'Language',
    settings_note: 'Choose your preferred UI language. Arabic will enable RTL layout.',
    account_title: 'Account',
    signup_btn: 'Sign up',
    login_btn: 'Log in',
    logout_btn: 'Log out',
    signed_in_as: 'Signed in as',
    home_panel: 'Welcome to the Home panel. Use the side buttons to switch sections.',
  about_panel: 'This app is made in Tunisia.',
    settings_panel: 'Settings panel. Configure your preferences here.',
  help_panel: 'Get help and support at fadidammak7@gmail.com',
    no_posts: 'No posts yet.'
  },
  fr: {
    home: 'Accueil',
    about: 'À propos',
    settings: 'Paramètres',
    help: 'Aide',
    settings_title: 'Paramètres',
    language_label: 'Langue',
    settings_note: "Choisissez votre langue d'interface. L'arabe activera le sens RTL.",
    account_title: 'Compte',
    signup_btn: "S'inscrire",
    login_btn: 'Se connecter',
    logout_btn: 'Se déconnecter',
    signed_in_as: 'Connecté en tant que',
    home_panel: "Bienvenue sur le panneau d'accueil. Utilisez les boutons latéraux pour changer de section.",
  about_panel: "Cette application est réalisée en Tunisie.",
    settings_panel: "Panneau des paramètres. Configurez vos préférences ici.",
  help_panel: "Obtenez de l'aide et du support à fadidammak7@gmail.com",
    no_posts: "Pas encore de publications."
  },
  ar: {
    home: 'الرئيسية',
    about: 'حول',
    settings: 'الإعدادات',
    help: 'مساعدة',
    settings_title: 'الإعدادات',
    language_label: 'اللغة',
    settings_note: 'اختر لغة الواجهة المفضلة. العربية ستفعل اتجاه من اليمين لليسار.',
    account_title: 'الحساب',
    signup_btn: 'التسجيل',
    login_btn: 'تسجيل الدخول',
    logout_btn: 'تسجيل الخروج',
    signed_in_as: 'مسجل الدخول باسم',
    home_panel: 'مرحبًا بك في لوحة الرئيسية. استخدم أزرار الجانب للتبديل بين الأقسام.',
  about_panel: 'هذا التطبيق مصنوع في تونس.',
    settings_panel: 'لوحة الإعدادات. قم بتكوين تفضيلاتك هنا.',
  help_panel: 'احصل على المساعدة والدعم على fadidammak7@gmail.com',
    no_posts: 'لا توجد منشورات بعد.'
  }
};

function applyTranslations(lang) {
  // nav buttons: only update label spans so icons remain
  document.querySelectorAll('.nav-btn').forEach(btn => {
    const key = btn.dataset.target;
    const label = btn.querySelector('.label');
    if (label) label.textContent = translations[lang][key] || label.textContent;
  });

  // page title (if visible)
  const active = document.querySelector('.nav-btn.active');
  if (active) pageTitle.textContent = translations[lang][active.dataset.target] || pageTitle.textContent;

  // translatable elements with data-i18n
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const k = el.getAttribute('data-i18n');
    if (!translations[lang] || !translations[lang][k]) return;
    if (k === 'help_panel') {
      // help_panel may contain HTML (mailto link)
      el.innerHTML = translations[lang][k].replace(/fadidammak7@gmail\.com/g, '<a href="mailto:fadidammak7@gmail.com">fadidammak7@gmail.com</a>');
    } else {
      el.textContent = translations[lang][k];
    }
  });

  // panel contents are translated via data-i18n attributes above; do not overwrite panel inner HTML

  // RTL handling for Arabic
  if (lang === 'ar') {
    document.documentElement.dir = 'rtl';
    document.documentElement.lang = 'ar';
    document.body.style.textAlign = 'right';
  } else {
    document.documentElement.dir = 'ltr';
    document.documentElement.lang = lang;
    document.body.style.textAlign = '';
  }
}

function saveLanguage(lang) {
  try { localStorage.setItem('ui_lang', lang); } catch (e) { /* ignore */ }
}

function loadLanguage() {
  let lang = 'en';
  try { lang = localStorage.getItem('ui_lang') || 'en'; } catch (e) { lang = 'en'; }
  return ['en','fr','ar'].includes(lang) ? lang : 'en';
}


buttons.forEach(btn => {
  // support both click and touchstart to improve responsiveness on some mobile browsers
  const onActivate = (e) => {
    // prevent double events
    if (e && e.type === 'touchstart') e.preventDefault();
    // update active
    buttons.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    // show target panel
    const target = btn.dataset.target;
    panels.forEach(p => p.classList.add('hidden'));
    const el = document.getElementById(target);
    if (el) el.classList.remove('hidden');

    // update title
    pageTitle.textContent = target.charAt(0).toUpperCase() + target.slice(1);

    // if the button requested a scroll into a subsection (for example Account inside Settings)
    const scrollTo = btn.dataset.scrollTo;
    if (scrollTo) {
      // small timeout so panel is visible and layout is updated
      setTimeout(() => {
        const el = document.getElementById(scrollTo);
        if (el) el.scrollIntoView({behavior: 'smooth', block: 'start'});
      }, 120);
    }

    // on small screens hide sidebar after click
    if (window.innerWidth <= 720 && sidebar.classList.contains('open')) {
      sidebar.classList.remove('open');
    }
  };

  btn.addEventListener('click', onActivate);
  btn.addEventListener('touchstart', onActivate, {passive: false});
});

toggleBtn.addEventListener('click', () => {
  // collapse/expand the sidebar
  sidebar.classList.toggle('collapsed');
  if (sidebar.classList.contains('collapsed')) toggleBtn.textContent = '⟩';
  else toggleBtn.textContent = '⟨';
});
const toggleSidebarCollapsed = (e) => {
  if (e && e.type === 'touchstart') e.preventDefault();
  sidebar.classList.toggle('collapsed');
  if (sidebar.classList.contains('collapsed')) toggleBtn.textContent = '\u27e9';
  else toggleBtn.textContent = '\u27e8';
};
toggleBtn.addEventListener('click', toggleSidebarCollapsed);
toggleBtn.addEventListener('touchstart', toggleSidebarCollapsed, {passive:false});

// Mobile menu button opens/closes the sliding sidebar on small screens
if (mobileMenuBtn) {
  const toggleOverlaySidebar = (e) => {
    if (e && e.type === 'touchstart') e.preventDefault();
    sidebar.classList.toggle('open');
  };
  mobileMenuBtn.addEventListener('click', toggleOverlaySidebar);
  mobileMenuBtn.addEventListener('touchstart', toggleOverlaySidebar, {passive:false});

  // close sidebar when tapping outside it on mobile
  document.addEventListener('click', (e) => {
    if (window.innerWidth > 720) return;
    if (!sidebar.classList.contains('open')) return;
    if (!e.composedPath) return; // older browsers
    const path = e.composedPath();
    if (!path.includes(sidebar) && !path.includes(mobileMenuBtn)) {
      sidebar.classList.remove('open');
    }
  });
  document.addEventListener('touchstart', (e) => {
    if (window.innerWidth > 720) return;
    if (!sidebar.classList.contains('open')) return;
    const path = e.composedPath ? e.composedPath() : [];
    if (path.length && !path.includes(sidebar) && !path.includes(mobileMenuBtn)) {
      sidebar.classList.remove('open');
    }
  }, {passive:true});
}

// Allow pressing 'm' to toggle mobile sidebar for demo
window.addEventListener('keydown', (e) => {
  if (e.key.toLowerCase() === 'm' && window.innerWidth <= 720) {
    sidebar.classList.toggle('open');
  }
});

// Accessibility: allow keyboard nav
let currentIndex = 0;
window.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowDown') {
    currentIndex = Math.min(buttons.length - 1, currentIndex + 1);
    buttons[currentIndex].focus();
  } else if (e.key === 'ArrowUp') {
    currentIndex = Math.max(0, currentIndex - 1);
    buttons[currentIndex].focus();
  }
});

// --- Language selector wiring ---
if (languageSelect) {
  // initialize select and translations
  const initialLang = loadLanguage();
  languageSelect.value = initialLang;
  applyTranslations(initialLang);

  languageSelect.addEventListener('change', (e) => {
    const lang = e.target.value;
    applyTranslations(lang);
    saveLanguage(lang);
  });
}

// keep currentIndex in sync with focused button
buttons.forEach((b, idx) => b.addEventListener('focus', () => currentIndex = idx));

// ensure pageTitle is correct on load
const activeBtn = document.querySelector('.nav-btn.active');
if (activeBtn) pageTitle.textContent = translations[loadLanguage()][activeBtn.dataset.target] || pageTitle.textContent;

// Auto-open Settings on first load so the language selector is visible for you
window.addEventListener('load', () => {
  const settingsBtn = document.querySelector('.nav-btn[data-target="settings"]');
  if (settingsBtn) {
    // simulate click to open settings panel
    settingsBtn.click();
    // ensure sidebar is expanded so the selector is visible
    sidebar.classList.remove('collapsed');
  }

  // --- Posts feed logic ---
  const postsKey = 'posts_feed_v1';
  const usersKey = 'accounts_v1';
  const sessionKey = 'session_user';
  const featuredKey = 'featured_accounts_v1';
  const verifiedKey = 'verified_accounts_v1';
  const pfpKey = 'pfp_by_user_v1';
  const postInput = document.getElementById('postInput');
  const postBtn = document.getElementById('postBtn');
  const postsList = document.getElementById('postsList');
  const charCount = document.getElementById('charCount');
  const attachVideoBtn = document.getElementById('attachVideoBtn');
  const attachVideoFile = document.getElementById('attachVideoFile');
  const attachImageBtn = document.getElementById('attachImageBtn');
  const attachImageFile = document.getElementById('attachImageFile');
  let currentAttachment = null; // video data URL
  let currentImageAttachment = null; // image data URL
  const signupUser = document.getElementById('signupUser');
  const signupPass = document.getElementById('signupPass');
  const signupBtn = document.getElementById('signupBtn');
  const loginUser = document.getElementById('loginUser');
  const loginPass = document.getElementById('loginPass');
  const loginBtn = document.getElementById('loginBtn');
  const logoutBtn = document.getElementById('logoutBtn');
  const sessionInfo = document.getElementById('sessionInfo');
  const authForms = document.getElementById('authForms');
  const logoutRow = document.getElementById('logoutRow');

  function loadPosts() {
    try { return JSON.parse(localStorage.getItem(postsKey) || '[]'); } catch (e) { return []; }
  }
  function savePosts(arr) { try { localStorage.setItem(postsKey, JSON.stringify(arr)); } catch (e) {} }

  // featured/verified helpers
  function loadFeatured() { try { return JSON.parse(localStorage.getItem(featuredKey) || '[]'); } catch (e) { return []; } }
  function saveFeatured(arr) { try { localStorage.setItem(featuredKey, JSON.stringify(arr)); } catch (e) {} }
  function loadVerified() { try { return JSON.parse(localStorage.getItem(verifiedKey) || '[]'); } catch (e) { return []; } }
  function saveVerified(arr) { try { localStorage.setItem(verifiedKey, JSON.stringify(arr)); } catch (e) {} }
  function loadPfps() { try { return JSON.parse(localStorage.getItem(pfpKey) || '{}'); } catch (e) { return {}; } }
  function savePfps(obj) { try { localStorage.setItem(pfpKey, JSON.stringify(obj)); } catch (e) {} }

  // ensure the demo account is verified by default
  (function ensureDefaultVerified(){
    const v = loadVerified();
    if (!v.includes('fadidammak7')) { v.push('fadidammak7'); saveVerified(v); }
  })();

  function renderPosts() {
    const posts = loadPosts();
    postsList.innerHTML = '';
    if (!posts.length) {
      const empty = document.createElement('div');
      empty.className = 'muted';
      empty.textContent = translations[loadLanguage()]['no_posts'] || 'No posts yet';
      postsList.appendChild(empty);
      return;
    }
      const featured = loadFeatured();
      const verified = loadVerified();
      const pfps = loadPfps();
      posts.slice().reverse().forEach(p => {
  const el = document.createElement('div'); el.className = 'post';
  if (p.user && featured.includes(p.user)) el.classList.add('featured');
  const meta = document.createElement('div'); meta.className = 'meta';
  // avatar
  // prefer avatar snapshot saved with the post; fall back to current user pfp mapping
  const avatarSrc = p.pfp || (p.user && pfps[p.user]) || null;
  if (avatarSrc) {
    const img = document.createElement('img'); img.className = 'avatar small'; img.src = avatarSrc; img.alt = (p.user || 'user') + ' avatar';
    meta.appendChild(img);
  }
  const tsText = document.createTextNode(`${new Date(p.ts).toLocaleString()}`);
  meta.appendChild(tsText);
  if (p.user) {
    const userNode = document.createElement('span'); userNode.style.marginLeft = '8px'; userNode.textContent = p.user;
    if (verified.includes(p.user)) {
      const vb = document.createElement('span'); vb.className = 'verified-badge'; vb.textContent = '✔';
      userNode.appendChild(vb);
    }
    meta.appendChild(userNode);
  }
  const body = document.createElement('div'); body.className = 'body'; body.textContent = p.text;
      // attached image (if any)
      if (p.imageData) {
        const img = document.createElement('img'); img.src = p.imageData; img.alt = 'attached image';
        el.appendChild(img);
      }
      // attached video (if any)
      if (p.videoData) {
        const vid = document.createElement('video'); vid.controls = true; vid.src = p.videoData; vid.className = 'attached-video';
        el.appendChild(vid);
      }
      const actions = document.createElement('div'); actions.className = 'actions';
      const del = document.createElement('button'); del.textContent = 'Delete';
      del.addEventListener('click', () => {
        const remaining = loadPosts().filter(x => x.ts !== p.ts);
        savePosts(remaining);
        renderPosts();
      });
      actions.appendChild(del);
      el.appendChild(meta); el.appendChild(body); el.appendChild(actions);
      postsList.appendChild(el);
    });
  }

  if (postInput && charCount) {
    postInput.addEventListener('input', () => {
      charCount.textContent = 280 - postInput.value.length;
    });
  }

  if (postBtn && postInput) {
    postBtn.addEventListener('click', () => {
      const text = postInput.value.trim();
      if (!text) return;
  const posts = loadPosts();
  const currentUser = localStorage.getItem(sessionKey) || null;
  // attach current user's pfp snapshot to the post so it persists with the post
  const pfps = loadPfps();
  const postPfp = currentUser && pfps[currentUser] ? pfps[currentUser] : null;
  const postObj = { ts: Date.now(), text, user: currentUser, pfp: postPfp };
  if (currentAttachment) postObj.videoData = currentAttachment;
  if (currentImageAttachment) postObj.imageData = currentImageAttachment;
  posts.push(postObj);
  // clear attachment after post
  currentAttachment = null;
  currentImageAttachment = null;
  const preview = document.querySelector('.composer video.preview'); if (preview) preview.remove();
  const previewImg = document.querySelector('.composer img.preview'); if (previewImg) previewImg.remove();
      savePosts(posts);
      postInput.value = '';
      if (charCount) charCount.textContent = 280;
      renderPosts();
    });
  }

  // handle attach button and file input
  if (attachVideoBtn && attachVideoFile) {
    attachVideoBtn.addEventListener('click', () => attachVideoFile.click());
    attachVideoFile.addEventListener('change', (e) => {
      const f = e.target.files && e.target.files[0];
      if (!f) return;
      // size guard: 6MB
      const maxBytes = 6 * 1024 * 1024;
      if (f.size > maxBytes) return alert('File too large (max 6MB for demo).');
      const reader = new FileReader();
      reader.onload = () => {
        currentAttachment = reader.result;
        // show small preview in composer
        const existing = document.querySelector('.composer video.preview');
        if (existing) existing.remove();
        const v = document.createElement('video'); v.className = 'preview'; v.controls = true; v.src = currentAttachment;
        const composer = document.querySelector('.composer');
        if (composer) composer.appendChild(v);
      };
      reader.readAsDataURL(f);
    });
  }

  // handle image attach (zid haja)
  if (attachImageBtn && attachImageFile) {
    attachImageBtn.addEventListener('click', () => attachImageFile.click());
    attachImageFile.addEventListener('change', (e) => {
      const f = e.target.files && e.target.files[0];
      if (!f) return;
      // size guard: 6MB
      const maxBytes = 6 * 1024 * 1024;
      if (f.size > maxBytes) return alert('Image too large (max 6MB for demo).');
      const reader = new FileReader();
      reader.onload = () => {
        currentImageAttachment = reader.result;
        // remove any existing video preview to avoid clutter
        const existingVideo = document.querySelector('.composer video.preview'); if (existingVideo) existingVideo.remove();
        const existingImg = document.querySelector('.composer img.preview'); if (existingImg) existingImg.remove();
        const img = document.createElement('img'); img.className = 'preview'; img.src = currentImageAttachment; img.alt = 'image preview';
        const composer = document.querySelector('.composer');
        if (composer) composer.appendChild(img);
      };
      reader.readAsDataURL(f);
    });
  }

  // initial render
  renderPosts();

  // --- User accounts ---
  function loadUsers() { try { return JSON.parse(localStorage.getItem(usersKey) || '{}'); } catch (e) { return {}; } }
  function saveUsers(u) { try { localStorage.setItem(usersKey, JSON.stringify(u)); } catch (e) {} }
  function hashPass(p) { return btoa(unescape(encodeURIComponent(p))); } // demo-only

  function renderSession() {
    const cur = localStorage.getItem(sessionKey);
    if (cur) {
      if (sessionInfo) {
        sessionInfo.hidden = false;
        // show verified badge if applicable
        const verified = loadVerified();
        sessionInfo.textContent = '';
        const nameSpan = document.createElement('span'); nameSpan.className = 'session-username'; nameSpan.textContent = cur;
        sessionInfo.appendChild(document.createTextNode('Signed in as '));
        sessionInfo.appendChild(nameSpan);
        if (verified.includes(cur)) {
          const vb = document.createElement('span'); vb.className = 'verified-badge'; vb.textContent = '✔';
          nameSpan.appendChild(vb);
        }
      }
      if (authForms) authForms.hidden = true;
      if (logoutRow) logoutRow.hidden = false;
    } else {
      if (sessionInfo) sessionInfo.hidden = true;
      if (authForms) authForms.hidden = false;
      if (logoutRow) logoutRow.hidden = true;
    }
  }

  if (signupBtn && signupUser && signupPass) {
    signupBtn.addEventListener('click', () => {
      const u = signupUser.value.trim(); const p = signupPass.value;
      if (!u || !p) return alert('Enter username and password');
      const users = loadUsers();
      if (users[u]) return alert('User exists');
      users[u] = { pass: hashPass(p) };
      saveUsers(users);
      localStorage.setItem(sessionKey, u);
      renderSession();
    });
  }

  if (loginBtn && loginUser && loginPass) {
    loginBtn.addEventListener('click', () => {
      const u = loginUser.value.trim(); const p = loginPass.value;
      if (!u || !p) return alert('Enter login and password');
      const users = loadUsers();
      if (!users[u] || users[u].pass !== hashPass(p)) return alert('Invalid credentials');
      localStorage.setItem(sessionKey, u);
      renderSession();
    });
  }

  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      localStorage.removeItem(sessionKey);
      renderSession();
    });
  }

  // Feature toggle button for demo account
  const featureFadiBtn = document.getElementById('featureFadiBtn');
  if (featureFadiBtn) {
    featureFadiBtn.addEventListener('click', () => {
      const featured = loadFeatured();
      const idx = featured.indexOf('fadidammak7');
      if (idx === -1) {
        featured.push('fadidammak7');
      } else {
        featured.splice(idx,1);
      }
      saveFeatured(featured);
      renderPosts();
      alert(`fadidammak7 is now ${featured.includes('fadidammak7') ? 'featured' : 'not featured'}`);
    });
  }
  // PFP controls wiring (must be inside load handler so helpers are in scope)
  const uploadPfpBtn = document.getElementById('uploadPfpBtn');
  const removePfpBtn = document.getElementById('removePfpBtn');
  const pfpFile = document.getElementById('pfpFile');
  const pfpPreviewContainer = document.getElementById('pfpPreviewContainer');
  function setPfpPreview(data) {
    if (!pfpPreviewContainer) return;
    pfpPreviewContainer.innerHTML = '';
    if (data) {
      const img = document.createElement('img'); img.src = data; img.alt = 'pfp preview';
      pfpPreviewContainer.appendChild(img);
    }
  }
  if (uploadPfpBtn && pfpFile) {
    uploadPfpBtn.addEventListener('click', () => pfpFile.click());
    pfpFile.addEventListener('change', (e) => {
      const f = e.target.files && e.target.files[0]; if (!f) return;
      const reader = new FileReader();
      reader.onload = () => {
        const data = reader.result;
        const cur = localStorage.getItem(sessionKey);
        if (!cur) return alert('Please sign in to set a profile picture');
        const pfps = loadPfps(); pfps[cur] = data; savePfps(pfps);
        setPfpPreview(data);
        renderSession(); renderPosts();
      };
      reader.readAsDataURL(f);
    });
  }
  if (removePfpBtn) {
    removePfpBtn.addEventListener('click', () => {
      const cur = localStorage.getItem(sessionKey); if (!cur) return alert('Please sign in first');
      const pfps = loadPfps(); delete pfps[cur]; savePfps(pfps);
      setPfpPreview(null);
      renderSession(); renderPosts();
    });
  }

  // set preview for current user if available
  const previewPfps = loadPfps();
  const curUser = localStorage.getItem(sessionKey);
  if (curUser && previewPfps[curUser]) setPfpPreview(previewPfps[curUser]);

  renderSession();
});


  
