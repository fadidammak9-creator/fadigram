Fadigram - basic front-end

Files:
- index.html — main page with sidebar and content panels
- styles.css — styling for layout and responsive behavior
- script.js — simple interactions: switch panels, collapse sidebar, keyboard shortcuts

How to run:
1. Open `index.html` in your browser (double-click or right-click -> Open with > your browser).
2. On small screens press `m` to open the sidebar for demo.
3. Click the side buttons to switch panels. Click the toggle button to collapse/expand the sidebar.

Posts feature:
- The Home view now includes a post composer (280 chars) and a simple feed.
- Posts are saved to `localStorage` so they persist in your browser on this machine.

Attachments:
- You can attach a local video to a post using the "Attach video" button. For demo reasons attachments are stored as data URLs in localStorage.
- Be careful: localStorage has limited space (usually ~5-10MB). Use small videos (recommended < 6MB) or avoid attaching large files.

Serve with a local static server for best results (optional):
```powershell
cd 'C:\Users\HP\Desktop\code 2'
python -m http.server 8000
```
Then open http://localhost:8000 in your browser.

Notes:
- This is a minimal static front-end. No build step required.
- You can serve it with a static server for better mobile testing (e.g., `python -m http.server 8000`).
